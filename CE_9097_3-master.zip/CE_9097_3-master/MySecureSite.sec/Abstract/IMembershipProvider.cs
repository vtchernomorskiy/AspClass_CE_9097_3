﻿using MySecureSite.sec.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySecureSite.sec.Abstract
{
    public interface IMembershipProvider
    {
        User CreateUser(User u);
        bool Authenticate(User u);
        User GetUser(string username);
        IQueryable<User> Users { get; }
    }
}
