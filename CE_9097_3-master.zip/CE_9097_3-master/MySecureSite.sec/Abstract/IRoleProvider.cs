﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySecureSite.sec.Abstract
{
    public interface IRoleProvider
    {
        IQueryable<Entities.Role> Roles { get; }
        Entities.Role Create(Entities.Role role);
        void AddUserToRole(Entities.User user, Entities.Role role);
        void RemoveUserFromRole(Entities.User user, Entities.Role role);
        List<Entities.Role> GetRolesForUser(Entities.User user);
    }
}
