﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySecureSite.sec.Services
{
    public class RoleService
    {
        Abstract.IRoleProvider repository;

        public RoleService(Abstract.IRoleProvider repository)
        {
            this.repository = repository;
        }

        public IQueryable<Entities.Role> Roles
        {
            get { return repository.Roles; }
        }

        public Entities.Role Create(Entities.Role role)
        {
            return repository.Create(role);
        }

        public List<Entities.Role> RolesForUser(Entities.User user)
        {
            return repository.GetRolesForUser(user);
        }

        public void AddUserToRole(Entities.User user, Entities.Role role)
        {
            repository.AddUserToRole(user, role);
        }

        public void RemoveUserFromRole(Entities.User user, Entities.Role role)
        {
            repository.RemoveUserFromRole(user, role);
        }


    }
}
