﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySecureSite.sec.Services
{
    public class MembershipService
    {
        Abstract.IMembershipProvider repository;

        public MembershipService(Abstract.IMembershipProvider repository)
        {
            this.repository = repository;
        }

        public bool Authenticate(Entities.User user)
        {
            return repository.Authenticate(user);
        }

        public Entities.User GetUser(string username)
        {
            return repository.GetUser(username);
        }

        public Entities.User CreateUser(Entities.User u)
        {
            return repository.CreateUser(u);
        }

        public IQueryable<Entities.User> Users
        {
            get {
                return repository.Users;
            }
        }


    }
}
