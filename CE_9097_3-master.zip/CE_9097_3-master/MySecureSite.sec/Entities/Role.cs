﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySecureSite.sec.Entities
{
    public class Role
    {
        public string Name { get; set; }
    }
}
