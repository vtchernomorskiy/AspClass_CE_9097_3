﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySecureSite.sec.Entities
{
    public class RoleDetails
    {
        public string Name { get; set; }
        public List<User> Users { get; set; }
    }
}
