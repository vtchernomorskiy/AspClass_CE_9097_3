﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySecureSite.sec.Entities
{
    public class User
    {
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        public IQueryable<string> PartOf { get; set; }
        public IQueryable<Role> Roles { get; set; }
        public string Role { get; set; }
        public bool IsInRole { get; set; }
    }
}
