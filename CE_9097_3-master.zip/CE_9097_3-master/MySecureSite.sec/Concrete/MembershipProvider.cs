﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Security;

namespace MySecureSite.sec.Concrete
{
    public class MembershipProvider : Abstract.IMembershipProvider
    {

        public Entities.User CreateUser(Entities.User u)
        {
            MembershipCreateStatus status;
            Membership.CreateUser(u.Username, u.Password, u.Username, null, null, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
                var membershipUser = Membership.GetUser(u.Username);
                return new Entities.User { 
                    Username = u.Username
                };
            }
            throw new Exception(status.ToString());
        }


        public bool Authenticate(Entities.User u)
        {
            return Membership.ValidateUser(u.Username, u.Password);
        }

        public Entities.User GetUser(string username)
        {
            MembershipUser user;
            if (String.IsNullOrEmpty(username))
                user = Membership.GetUser();
            else
                user = Membership.GetUser(username);

            if (user == null)
                return null;

            return new sec.Entities.User { Username = user.UserName };
        }

        public IQueryable<Entities.User> Users
        {
            get {
                return Membership.GetAllUsers().OfType<MembershipUser>().Select(m => new Entities.User { Username = m.UserName }).AsQueryable();
            }
        }
    }
}
