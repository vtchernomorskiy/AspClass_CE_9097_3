﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using webSec = System.Web.Security;

namespace MySecureSite.sec.Concrete
{
    public class RoleProvider : Abstract.IRoleProvider
    {

        public IQueryable<Entities.Role> Roles
        {
            get {
                return webSec.Roles.GetAllRoles().Select(s => new Entities.Role { Name = s}).AsQueryable();
            }
        }

        public Entities.Role Create(Entities.Role role)
        {
            webSec.Roles.CreateRole(role.Name);
            var dbRole = webSec.Roles.GetAllRoles().SingleOrDefault(r=>r == role.Name);
            return new Entities.Role { Name = dbRole };
        }

        public void AddUserToRole(Entities.User user, Entities.Role role)
        {
            webSec.Roles.AddUserToRole(user.Username, role.Name);
        }

        public void RemoveUserFromRole(Entities.User user, Entities.Role role)
        {
            webSec.Roles.RemoveUserFromRole(user.Username, role.Name);
        }

        public List<Entities.Role> GetRolesForUser(Entities.User user)
        {
            return webSec.Roles.GetRolesForUser(user.Username).Select(s => new Entities.Role { Name = s }).ToList();
        }
    }
}
