﻿using MySecureSite.web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MySecureSite.web.Controllers
{
    [Authorize(Roles="SuperUser")]
    public class UserController : Controller
    {

        sec.Services.MembershipService memberSvc = new sec.Services.MembershipService(new sec.Concrete.MembershipProvider());
        sec.Services.RoleService roleSvc = new sec.Services.RoleService(new sec.Concrete.RoleProvider());

        public ActionResult Index()
        {
            var users = memberSvc.Users;
            return View(users);
        }

        public ActionResult AddUserToRole(string username, string role)
        {
            roleSvc.AddUserToRole(
                memberSvc.GetUser(username),
                new sec.Entities.Role {Name = role }
                );
            return RedirectToAction("Details", new { username = username});
        }

        public ActionResult RemoveUserFromRole(string username, string role)
        {
            roleSvc.RemoveUserFromRole(
                memberSvc.GetUser(username),
                new sec.Entities.Role { Name = role}
            );
            return RedirectToAction("Details", new { username = username });
        }
        public ActionResult Details(string username)
        {
            var user = memberSvc.GetUser(username);
            var allRoles = roleSvc.Roles.ToList();
            var rolesForUser = roleSvc.RolesForUser(user);
            var model = new UserDetailsViewModel {
                User = user,
                AllRoles = allRoles,
                UsersRoles = rolesForUser
            };
            return View(model);
        }
        public ActionResult Roles()
        {
            var model = roleSvc.Roles;
            return View(model);
        }
        public ActionResult CreateRole()
        {
            return View();
        }
        public ActionResult CreateUser()
        {
            var usr = new MySecureSite.sec.Entities.User { PartOf = memberSvc.Users.Select(u => u.Username), 
            Roles = roleSvc.Roles };
            return View(usr);
        }
        public ActionResult CreateNewRole(MySecureSite.sec.Entities.Role role)
        {
            var foundRole = roleSvc.Roles.FirstOrDefault(r => r.Name == role.Name);
            if (foundRole == null)
            {
                roleSvc.Create(role);
            }
            return RedirectToAction("Roles", "User");
        }
        public ActionResult CreateNewUser(MySecureSite.sec.Entities.User user)
        {
            var foundUser = memberSvc.Users.FirstOrDefault(u => u.Username == user.Username);
            if (foundUser == null)
            {
                memberSvc.CreateUser(user);
            }
            return RedirectToAction("Index");
        }
        public ActionResult RoleDetails(string id)
        {
            var model = new MySecureSite.sec.Entities.RoleDetails { Users = new List<MySecureSite.sec.Entities.User>(memberSvc.Users), Name = id };
            foreach (var usr in model.Users)
            {
                var rolesForUser = roleSvc.RolesForUser(usr).FirstOrDefault(ur => ur.Name == id);
                usr.IsInRole = (rolesForUser != null);
            }
            return View(model);
        }

        public ActionResult ChangeUserRole(string id)
        {
            string[] usrRole = id.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            var usr = new MySecureSite.sec.Entities.User { Username = usrRole[0] };
            var rolesForUser = roleSvc.RolesForUser(usr).ToArray();
            bool found = false;
            foreach (var role in rolesForUser)
            {
                if (role.Name == usrRole[1]) //found: remove
                {
                    if (usrRole[1] != "SuperUser")
                    {
                        roleSvc.RemoveUserFromRole(usr, role);
                        found = true;
                        break;
                    }
                    else
                    {
                        found = true;
                    }
                }
            }
            
            //if I am this point, not in role: add
            if (!found)
                roleSvc.AddUserToRole(usr, new MySecureSite.sec.Entities.Role { Name = usrRole[1] });

            return RedirectToAction("RoleDetails", new { id = usrRole[1] });
        }
    }
}
