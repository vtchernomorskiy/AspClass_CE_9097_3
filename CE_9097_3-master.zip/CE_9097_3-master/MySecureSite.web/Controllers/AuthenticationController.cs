﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MySecureSite.web.Controllers
{
    public class AuthenticationController : Controller
    {
        sec.Services.MembershipService svc = new sec.Services.MembershipService(new sec.Concrete.MembershipProvider());
        sec.Services.RoleService roleSvc = new sec.Services.RoleService(new sec.Concrete.RoleProvider());

        public AuthenticationController()
        {

        }
        public AuthenticationController(sec.Abstract.IMembershipProvider membershipProvider)
        {
            svc = new sec.Services.MembershipService(membershipProvider);
        }

        private void SetCookie(sec.Entities.User user)
        {
            FormsAuthentication.SetAuthCookie(user.Username, false);
        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult Login()
        {
            var user = new sec.Entities.User { };
            return View(user);
        }

        [HttpPost]
        public ActionResult Login(sec.Entities.User user)
        {
            if (svc.Authenticate(user))
            {
                SetCookie(user);
                return RedirectToAction("Index", "Home");
            }
            ModelState.AddModelError(String.Empty, "Bad Credentials");

            return View(user);
        }

        public ActionResult Create()
        {
            var user = new sec.Entities.User { };
            user.PartOf = svc.Users.Select(u => u.Username);
            user.Roles = roleSvc.Roles;
            return View(user);
        }

        [HttpPost]
        public ActionResult Create(sec.Entities.User user)
        {
            if (svc.GetUser(user.Username) != null)
            {
                ModelState.AddModelError("Username", "This user already exists");
            }
            else
            {
                try
                {
                    svc.CreateUser(user);
                    var foundRole = roleSvc.Roles.FirstOrDefault(r => r.Name == user.Role);
                    if (foundRole != null)
                    {
                        roleSvc.AddUserToRole(user, foundRole);
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(String.Empty, ex.Message);
                }
            }
            if (ModelState.IsValid)
            {
                user.PartOf = svc.Users.Select(u => u.Username); 
                SetCookie(user);
                return RedirectToAction("Index", "Home");
            }
           
            return View(user);
        }

        public ActionResult LoginStatus()
        {
            var user = svc.GetUser(null);
            return View(user);
        }

    }
}
