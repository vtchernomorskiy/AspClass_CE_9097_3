﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MySecureSite.web.Models
{
    public class UserDetailsViewModel
    {
        public sec.Entities.User User { get; set; }
        public List<sec.Entities.Role> UsersRoles { get; set; }
        public List<sec.Entities.Role> AllRoles { get; set; }

        public bool IsUserInRole(sec.Entities.Role role){
            return UsersRoles.Any(r => r.Name == role.Name);
        }
    }
}