﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;

namespace MySecureSite.web
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            var roleService = new sec.Services.RoleService(new sec.Concrete.RoleProvider());

            if(!roleService.Roles.Any(r=>r.Name == "Admin"))
                roleService.Create(new sec.Entities.Role{Name = "Admin"});

            if(!roleService.Roles.Any(r=>r.Name == "User"))
                roleService.Create(new sec.Entities.Role{Name = "User"});
            if (!roleService.Roles.Any(r => r.Name == "SuperUser"))
                roleService.Create(new sec.Entities.Role { Name = "SuperUser" });



            AreaRegistration.RegisterAllAreas();

            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
    }
}